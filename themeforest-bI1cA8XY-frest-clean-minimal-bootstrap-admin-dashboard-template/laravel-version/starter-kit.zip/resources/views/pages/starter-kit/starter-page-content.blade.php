<section class="row">
    <div class="col-sm-12">
        <!-- Kick start -->
        <div id="kick-start" class="card">
            <div class="card-header">
                <h4 class="card-title">Kick start your project development !</h4>
                <a class="heading-elements-toggle"></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                      <li><a data-action="collapse"><i class="bx bx-chevron-down"></i></a></li>
                      <li><a data-action="expand"><i class="bx bx-fullscreen"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body">
                    <div class="card-text">
                        <p>Getting start with your project custom requirements using a ready template which is quite difficult and time taking process, Stack Admin provides useful features to kick start your project development with no efforts !</p>
                        <ul>
                            <li>Stack Admin provides you getting start pages with different layouts, use the layout as per your custom requirements and just change the branding, menu & content.</li>
                            <li>It use template engine to generate pages and whole template quickly using node js. You can generate entire template with your selected custom layout, branding & menu. Save your time for doing the common changes for
                                each page (i.e menu, branding and footer) by generating template.</li>
                            <li>Every components in Stack Admin are decoupled, it means use use only components you actually need! Remove unnecessary and extra code easily just by excluding the path to specific SCSS, JS file.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--/ Kick start -->

        <!-- What is-->
        <div id="what-is" class="card">
            <div class="card-header">
                <h4 class="card-title">What is starter kit ?</h4>
                <a class="heading-elements-toggle"></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                      <li><a data-action="collapse"><i class="bx bx-chevron-down"></i></a></li>
                      <li><a data-action="expand"><i class="bx bx-fullscreen"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body">
                    <div class="card-text">
                        <p>Starter kit is a set of pages with different layouts, useful for your next project to start development process from scratch with no time. </p>
                        <ul>
                            <li>Each layout includes basic components only.</li>
                            <li>Select your choice of layout from starter kit, customize it with optional changes like colors and branding, add required dependency only.</li>
                            <li>Using template engine to generate whole template quickly with your selected layout and other custom changes.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--/ What is-->

        <!-- How to-->
        <div id="how-to" class="card">
            <div class="card-header">
                <h4 class="card-title">How to use starter kit ?</h4>
                <a class="heading-elements-toggle"></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                      <li><a data-action="collapse"><i class="bx bx-chevron-down"></i></a></li>
                      <li><a data-action="expand"><i class="bx bx-fullscreen"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body">
                    <div class="card-text">
                        <p><span class="text-bold-600 mt-2">HTML</span></p>
                        <p>If you know just HTML, select your choice of layout from starter kit folder, customize it with optional changes like colors and branding, add required dependency only.</p>
                        <div class="alert alert-icon-left alert-arrow-left alert-info mb-2" role="alert">
                            <h4>Tip!</h4>
                            <p>Hideable navbar option is available for fixed navbar with static navigation only. Works in top and bottom positions, single and multiple navbars.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ How to-->

        <!-- Simple Card-->
        <div id="simple-card" class="card">
            <div class="card-header">
                <h4 class="card-title">Simple Card</h4>
                <a class="heading-elements-toggle"></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                      <li><a data-action="collapse"><i class="bx bx-chevron-down"></i></a></li>
                      <li><a data-action="expand"><i class="bx bx-fullscreen"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body">
                    <div class="card-text">
                        <h5>HTML Ipsum Presents</h5>
                        <p><strong>Pellentesque habitant morbi tristique</strong> senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas
                            semper. <em>Aenean ultricies mi vitae est.</em> Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed, <code>commodo vitae</code>, ornare sit amet, wisi. Aenean
                            fermentum, elit eget tincidunt condimentum, eros ipsum rutrum orci, sagittis tempus lacus enim ac dui. <a href="javascript:void(0);">Donec non enim</a> in turpis pulvinar facilisis. Ut felis.</p>
                        <h6>Header Level 2</h6>

                        <ol>
                            <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
                            <li>Aliquam tincidunt mauris eu risus.</li>
                        </ol>

                        <blockquote>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus magna. Cras in mi at felis aliquet congue. Ut a est eget ligula molestie gravida. Curabitur massa. Donec eleifend, libero at sagittis mollis, tellus est malesuada
                                tellus, at luctus turpis elit sit amet quam. Vivamus pretium ornare est.</p>
                        </blockquote>

                        <h3>Header Level 3</h3>

                        <ul>
                            <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
                            <li>Aliquam tincidunt mauris eu risus.</li>
                        </ul>

                        <pre><code class="language-css">
                            #header h1 a {
                            	display: block;
                            	width: 300px;
                            	height: 80px;
                            }
                        </code></pre>
                        <dl>
                            <dt>Definition list</dt>
                            <dd>Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</dd>
                            <dt>Lorem ipsum dolor sit amet</dt>
                            <dd>Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
        <!--/ How to-->
    </div>
</section>

<section class="row">
    <div class="col-md-6 col-sm-12">
        <div id="with-header" class="card">
            <div class="card-header">
                <h4 class="card-title">With Header</h4>
                <a class="heading-elements-toggle"></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                      <li><a data-action="collapse"><i class="bx bx-chevron-down"></i></a></li>
                      <li><a data-action="expand"><i class="bx bx-fullscreen"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body border-top-blue-grey border-top-lighten-5 ">
                    <h4 class="card-title">Content title</h4>
                    <p class="card-text">Add a heading to card with <code>.card-header </code> class &amp; content title uses <code>.card-title</code> class. For border add <code>.border-top-COLOR</code> class</p>
                    <p class="card-text">You may also include any &lt;h1&gt;-&lt;h6&gt; with a <code>.card-header </code> &amp; <code>.card-title</code> class to add heading.</p>
                    <p class="card-text">Jelly beans sugar plum cheesecake cookie oat cake soufflé. Tart lollipop carrot cake sugar plum. Marshmallow wafer tiramisu jelly beans.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-sm-12">
        <div id="with-header-border-0" class="card">
            <div class="card-header">
                <h4 class="card-title">With Header &amp; No Border</h4>
                <a class="heading-elements-toggle"></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                      <li><a data-action="collapse"><i class="bx bx-chevron-down"></i></a></li>
                      <li><a data-action="expand"><i class="bx bx-fullscreen"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collapse show">
                <div class="card-body">
                    <h4 class="card-title">Content title</h4>
                    <p class="card-text">Add a heading to card with <code>.card-header </code> class &amp; content title uses <code>.card-title</code> class.</p>
                    <p class="card-text">You may also include any &lt;h1&gt;-&lt;h6&gt; with a <code>.card-header </code> &amp; <code>.card-title</code> class to add heading.</p>
                    <p class="card-text">Gingerbread brownie sweet roll cheesecake chocolate cake jelly beans marzipan gummies dessert. Jelly beans sugar plum cheesecake cookie oat cake soufflé.</p>
                </div>
            </div>
        </div>
    </div>
</section>
